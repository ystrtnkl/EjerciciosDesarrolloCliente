import React from 'react'
import './App.css';
import './components/Matricula/Matricula.jsx';
import Matricula from './components/Matricula/Matricula.jsx';

function App() {

  return (
    <>
      <Matricula />
    </>
  )
}

export default App
