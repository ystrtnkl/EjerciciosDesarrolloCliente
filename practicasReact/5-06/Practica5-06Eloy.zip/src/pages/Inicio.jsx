import React from 'react';

//Página de inicio de la aplicación, accesible desde / y desde /inicio.
function Inicio() {

  return (
    <>
        <h2>Esta es la página de Inicio.</h2>
        <p>Realmente no hay mucho que mostrar en la página de inicio, prueba a navegar con la barra de navegación.</p>
        <p>Con esta aplicación puedes adminstrar tus discos.</p>
        <p>De momento, los discos se guardan en LocalStorage.</p>
    </>
  )
}

export default Inicio;
