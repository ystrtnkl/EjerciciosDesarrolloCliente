import React from 'react';
import FormularioPerfil from '../components/Formularios/FormularioPerfil';

function MiPerfil() {

  return (
    <>
        <h2>Mi perfil.</h2>
        <FormularioPerfil />
    </>
  )
}

export default MiPerfil;
