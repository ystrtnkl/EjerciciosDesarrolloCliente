import React from 'react';

//La página de Acerca De, con información relevante de la aplicación.
function AcercaDe() {

  return (
    <>
        <h2>Esta es la página de Acerca de.</h2>
        <p>Aquí está la información del ejercicio, aunque la mayoría de información se encuentra en los comentarios del código</p>
        <p>Versión: 1.0.0</p>
        <p>Autor: Eloy Rico Payá</p>
        <p>Fecha de última modificación registrada: 22/10/2025</p>
    </>
  )
}

export default AcercaDe;
