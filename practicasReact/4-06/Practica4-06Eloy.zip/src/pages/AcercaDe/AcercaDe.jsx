import React from 'react';
import './AcercaDe.css';
import VolverInicio from '../../components/VolverInicio/VolverInicio';

function AcercaDe() {

  return (
    <>
      <h2>Esta es la página de Acerca de.</h2>
      <VolverInicio />
    </>
  )
}

export default AcercaDe;
