import React from 'react';
import './Contacto.css';
import VolverInicio from '../../components/VolverInicio/VolverInicio';

function Contacto() {

  return (
    <>
      <h2>Esta es la página de Contacto.</h2>
      <VolverInicio />
    </>
  )
}

export default Contacto;
