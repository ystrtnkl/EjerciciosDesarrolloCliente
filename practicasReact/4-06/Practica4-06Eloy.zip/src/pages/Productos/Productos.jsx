import React from 'react';
import './Productos.css';
import VolverInicio from '../../components/VolverInicio/VolverInicio';

function Productos() {

  return (
    <>
      <h2>Esta es la página de Productos.</h2>
      <VolverInicio />
    </>
  )
}

export default Productos;
