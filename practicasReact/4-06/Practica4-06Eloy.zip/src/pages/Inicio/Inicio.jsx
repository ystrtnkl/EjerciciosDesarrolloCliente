import React from 'react';
import './Inicio.css';

function Inicio() {

  return (
    <>
        <h2>Esta es la página de Inicio.</h2>
    </>
  )
}

export default Inicio;
