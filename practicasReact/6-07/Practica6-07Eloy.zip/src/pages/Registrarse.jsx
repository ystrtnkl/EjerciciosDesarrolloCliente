import React from 'react';
import FormularioRegister from '../components/Formularios/FormularioRegister.jsx';

function Registrarse() {

  return (
    <>
        <h2>Crear cuenta</h2>
        <FormularioRegister />
    </>
  )
}

export default Registrarse;
