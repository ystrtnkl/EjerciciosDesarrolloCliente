import React from 'react';
import FormularioLogin from '../components/Formularios/FormularioLogin';

function Login() {

  return (
    <>
        <h2>Iniciar sesión</h2>
        <FormularioLogin />
    </>
  )
}

export default Login;
